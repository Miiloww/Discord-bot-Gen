## Fonctionnalités

### Système de Statut et Rôles
- Attribution automatique de rôle aux utilisateurs ayant un texte spécifique dans leur statut Discord
- Vérification automatique toutes les 30 secondes
- Retrait du rôle si le statut est modifié

### Panel de G3n Principal
- Affichage moderne avec Discord Components v2 (ContainerBuilder, SeparatorBuilder)
- Liste de tous les services disponibles avec compteur de stock en temps réel
- Boutons pour chaque service
- Vérification automatique du rôle requis
- Génération de codes uniques (13 caractères alphanumériques)
- Support VIP et Free

### Système de Tickets
- Création de tickets privés pour récupérer les comptes
- Limite d'1 ticket actif par utilisateur
- Cooldown configurables : 5 minutes (normal) / 1 minute (VIP)
- Validation automatique du code
- Détection automatique du service
- Envoi du compte en message éphémère
- Fermeture automatique après 5 minutes ou manuelle

### Panel Custom Administratif
- Modifier les cooldowns (s/m/h/j)
- Ajouter/Supprimer des services
- Configurer le salon de restock et le rôle à ping
- Configurer le salon de logs
- Ajouter du stock (format: email:password)
- Supprimer du stock

### Notifications de Restock
- Envoi automatique dans le salon configuré lors de l'ajout de comptes
- Affichage du service, quantité, type (Free/VIP)
- Ping du rôle configuré

### Logs de G3n
- Enregistrement de toutes les générations de comptes
- Affichage de l'utilisateur, service et heure

## Commandes

- `/panel-custom` - Affiche le panel de configuration admin (réservé aux admins)
- `/setup-status` - Configure le texte de statut requis et le rôle à attribuer
- `/panel-g3n` - Affiche le panel de génération de comptes
- `/panel-ticket` - Affiche le panel de création de tickets