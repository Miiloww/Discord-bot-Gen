# Installation du Bot Discord

## Prérequis

- Node.js 18 ou supérieur
- npm ou yarn
- Un bot Discord créé sur le [Discord Developer Portal](https://discord.com/developers/applications)

## Installation

1. **Décompresser l'archive**
   ```bash
   tar -xzf discord-bot.tar.gz
   cd discord-bot
   ```

2. **Installer les dépendances**
   ```bash
   npm install
   ```

3. **Configurer les variables d'environnement**
   
   Copier le fichier `.env.example` vers `.env` :
   ```bash
   cp .env.example .env
   ```
   
   Éditer le fichier `.env` et remplir les valeurs :
   ```env
   # Discord Bot Token (depuis le Developer Portal)
   DISCORD_BOT_TOKEN=votre_token_ici
   
   # Discord Application Credentials (pour OAuth2)
   DISCORD_CLIENT_ID=votre_client_id_ici
   DISCORD_CLIENT_SECRET=votre_client_secret_ici
   
   # ID du serveur Discord principal
   GUILD_ID=votre_guild_id_ici
   
   # Port (optionnel, par défaut 5000)
   PORT=5000
   ```

4. **Lancer le bot**
   ```bash
   npm run dev
   ```

## Configuration Discord

### Comment obtenir les informations nécessaires :

1. **DISCORD_BOT_TOKEN** :
   - Aller sur https://discord.com/developers/applications
   - Sélectionner votre application
   - Aller dans "Bot"
   - Cliquer sur "Reset Token" et copier le token

2. **DISCORD_CLIENT_ID** :
   - Sur la page de votre application
   - Aller dans "OAuth2" > "General"
   - Copier le "Client ID"

3. **DISCORD_CLIENT_SECRET** :
   - Sur la même page "OAuth2" > "General"
   - Copier ou générer un "Client Secret"

4. **GUILD_ID** :
   - Dans Discord, activer le mode développeur (Paramètres > Avancé > Mode développeur)
   - Faire clic droit sur votre serveur
   - Cliquer sur "Copier l'identifiant du serveur"

## Permissions du Bot

Lors de l'invitation du bot, assurez-vous qu'il a les permissions suivantes :
- Gérer les rôles
- Gérer les canaux
- Lire les messages/Voir les salons
- Envoyer des messages
- Créer des invitations
- Voir les membres (intent)
- Lire les présences (intent)

## Commandes disponibles

- `/panel-custom` - Affiche le panel de configuration (admin)
- `/panel-gen` - Affiche le panel de génération de comptes
- `/panel-ticket` - Affiche le panel de création de tickets
- `/panel-verification` - Affiche le panel de vérification

## Structure des données

Le bot stocke ses données dans le dossier `data/` :
- `config.json` - Configuration générale
- `services.json` - Services et comptes
- `stats.json` - Statistiques des utilisateurs
- `giveaway.json` - Historique des giveaways

## Support

Bot créé par **Miiloww**

Pour toute question ou problème, contactez le développeur.
